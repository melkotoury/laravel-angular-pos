<?php

return [

    'dashboard' => 'Tablero',
    'customers' => 'Clientes',
    'employees' => 'Empleados',
    'items' => 'Productos',
    'item_kits' => 'Combos',
    'suppliers' => 'Proveedores',
    'receivings' => 'Compras',
    'sales' => 'Ventas',
    'reports' => 'Reportes',
    'receivings_report' => 'Reporte de Compras',
    'sales_report' => 'Reporte de Ventas',
    'logout' => 'Cerrar Sesión',
    'application_settings' => 'Configuración del Sistema'
];
