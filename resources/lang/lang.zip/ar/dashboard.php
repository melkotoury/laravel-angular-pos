<?php

return [

	'welcome' 			=> 'Welcome to TutaPOS - TUTA Point of Sale.',
	'statistics' 		=> 'Statistics',
	'total_employees' 	=> 'Total Employees',
	'total_customers' 	=> 'Total Customers',
	'total_suppliers' 	=> 'Total Suppliers',
	'total_items' 		=> 'Total Items',
	'total_item_kits' 	=> 'Total Item Kits',
	'total_receivings' 	=> 'Total Receivings',
	'total_sales' 		=> 'Total Sales',

];
